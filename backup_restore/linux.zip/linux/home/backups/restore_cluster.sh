#gunzip -k -f /home/backup/cluster.sql.gz
gunzip -c /home/bkp/cluster.sql.gz | psql