sudo apt-get dist-upgrade
#apt-get install unattended-upgrades
apt-get update
apt-get upgrade
apt-cache search keyword postgresql-9.
apt-get install mc
apt-get install ssh
apt-get install htop
apt-get install pptp-linux
apt-get install cifs-utils
sudo -u postgres psql -c "ALTER USER postgres WITH ENCRYPTED PASSWORD '123' ; "
chown -R postgres /home/bkp/
mount -a
shutdown -r now
#crontab -u postgres -e
#service cron restart 
#chmod u+x pg_backup.sh pg_backup_rotated.sh
#sudo crontab -u postgres -e
#SHELL=/bin/bash
#15 3 * * * /path/to/script/pg_backup.sh > /dev/null 2>&1
#SHELL=/bin/bash
#0 14 * * * sheiss bash /home/sheiss/Scripts/test.sh > /home/sheiss/Scripts/test_`date +\%y\%m\%d`.log 2>test_`date +\%y\%m\%d`.err